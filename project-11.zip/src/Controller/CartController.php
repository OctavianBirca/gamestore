<?php

namespace App\Controller;


use App\Classe\Cart;
use App\Repository\ProductRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class CartController extends AbstractController
{
    #[Route('/mon-panier/{action}', name: 'app_cart', defaults: ['action' => null])]
    public function index(Cart $cart, $action): Response
    {   
        if ($action == "cancel") {
            $this->addFlash(
                'info',
                'Paiment annule. Vous pouvez mettre a jous votre panier et votre commande.'
            );
        }

        return $this->render('cart/index.html.twig', [
            'cart' => $cart->getCart(),
            'totalSum' => $cart->getTotalSum()
        ]);
    }

    #[Route('/cart/add/{id}', name: 'app_cart_add')]
    public function add($id, Cart $cart, ProductRepository $productRepository, Request $request): Response
    {   
        
        $product = $productRepository->findOneById($id);
        $cart->add($product);

        $this->addFlash(
            'success',
            "Le produit a ete ajoute a vortre panier"
        );

        return $this->redirect($request->headers->get('referer'));
       
           
    }

    #[Route('/cart/decrease/{id}', name: 'app_cart_decrease')]
    public function decrease($id, Cart $cart,): Response
    {   
        
        $cart->decrease($id);

        $this->addFlash(
            'success',
            "Le produit a ete retire de vortre panier"
        );

        return $this->redirectToRoute('app_cart');
       
           
    }






    #[Route('/cart/remove/', name: 'app_cart_remove')]
    public function remove(Cart $cart): Response
    { 
        
        $cart->remove();

        return $this->redirectToRoute('app_cart');
    
        
    }



}
